window.onload = function()
{     
    var searchBox =  document.getElementById("gsc-i-id1");
    searchBox.placeholder="Search webslake";
    searchBox.title="Search webslake";
}